﻿using BookStore.UI.Windows;

namespace BookStore.UI.HelperClasses;

public static class WindowsNavigation
{
    public static MainWindow MainWindow { get; set; }
    
    public static AuthWindow AuthWindow { get; set; }
}