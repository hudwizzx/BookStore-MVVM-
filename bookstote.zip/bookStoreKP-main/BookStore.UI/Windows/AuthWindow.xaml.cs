﻿using System.Windows;

namespace BookStore.UI.Windows;

public partial class AuthWindow : BaseWindow
{
    public AuthWindow()
    {
        InitializeComponent();
    }
}