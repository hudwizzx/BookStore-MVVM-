﻿namespace PAS.Storage.Models.Enums;

public enum PaymentType
{
    Cash,
    CardOffline
}