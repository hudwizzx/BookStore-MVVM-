﻿namespace BookStore.Storage;

public class StorageParameters
{
    public static string ConnectionString { get; set; }
}